class ApiConfig {
  static const String baseUrl = "http://10.0.2.2:5000";
  static String? authToken;

  static Map<String, String> get headers {
    return {
      'Content-Type': 'application/json',
      if (authToken != null) 'Authorization': 'Bearer $authToken',
    };
  }
}