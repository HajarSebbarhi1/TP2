import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import 'add_show_page.dart';
import 'profile_page.dart';
import 'update_show_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  List<dynamic> movies = [];
  List<dynamic> anime = [];
  List<dynamic> series = [];
  bool isLoading = true;

  // Créer un GlobalKey pour le RefreshIndicator
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey = 
      GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => isLoading = true);
    await fetchShows();
    setState(() => isLoading = false);
  }

  Future<void> fetchShows() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/shows'),
        headers: {'Cache-Control': 'no-cache'},
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> allShows = jsonDecode(response.body);
        
        setState(() {
          movies = allShows.where((show) => show['category'] == 'movie').toList();
          anime = allShows.where((show) => show['category'] == 'anime').toList();
          series = allShows.where((show) => show['category'] == 'serie').toList();
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${e.toString()}")),
      );
    }
  }

  // Méthode optimisée pour ajouter/mettre à jour un show localement
  void _updateShowLocally(dynamic updatedShow) {
    setState(() {
      // Supprimer l'ancienne version si elle existe
      movies.removeWhere((show) => show['id'] == updatedShow['id']);
      anime.removeWhere((show) => show['id'] == updatedShow['id']);
      series.removeWhere((show) => show['id'] == updatedShow['id']);

      // Ajouter dans la bonne catégorie
      switch (updatedShow['category']) {
        case 'movie':
          movies.add(updatedShow);
          break;
        case 'anime':
          anime.add(updatedShow);
          break;
        case 'serie':
          series.add(updatedShow);
          break;
      }
    });
  }

  void _navigateToAddPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddShowPage()),
    ).then((newShow) {
      if (newShow != null) {
        _updateShowLocally(newShow);
        _refreshIndicatorKey.currentState?.show();
      }
    });
  }

  void _navigateToUpdatePage(dynamic show) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UpdateShowPage(
          showId: show['id'],
          initialTitle: show['title'],
          initialDescription: show['description'],
          initialCategory: show['category'],
          initialImageUrl: show['image'] ?? '',
        ),
      ),
    ).then((updatedShow) {
      if (updatedShow != null) {
        _updateShowLocally(updatedShow);
      }
    });
  }

  Widget _buildShowList(List<dynamic> shows) {
    return RefreshIndicator(
      key: _refreshIndicatorKey,
      onRefresh: fetchShows,
      child: ListView.builder(
        itemCount: shows.length,
        itemBuilder: (context, index) {
          final show = shows[index];
          return _buildShowItem(show);
        },
      ),
    );
  }

  Widget _buildShowItem(dynamic show) {
    return Dismissible(
      key: Key(show['id'].toString()),
      background: _buildDeleteBackground(),
      direction: DismissDirection.endToStart,
      confirmDismiss: (direction) => _confirmDelete(show['id']),
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: ListTile(
          leading: _buildShowImage(show),
          title: Text(show['title']),
          subtitle: Text(show['description']),
          trailing: IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => _navigateToUpdatePage(show),
          ),
        ),
      ),
    );
  }

  // ... (autres méthodes restent similaires mais utilisent maintenant _updateShowLocally)

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Show App"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => _refreshIndicatorKey.currentState?.show(),
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : IndexedStack(
              index: _selectedIndex,
              children: [
                _buildShowList(movies),
                _buildShowList(anime),
                _buildShowList(series),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddPage,
        child: const Icon(Icons.add),
      ),
    );
  }
}