import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'profile_page.dart';
import 'add_show_page.dart';
import '../config/api_config.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  List<dynamic> _shows = [];

  @override
  void initState() {
    super.initState();
    _fetchShows();
  }

  Future<void> _fetchShows() async {
    try {
      final response = await http.get(Uri.parse('${ApiConfig.baseUrl}/shows'));
      if (response.statusCode == 200) {
        setState(() {
          _shows = json.decode(response.body);
        });
      } else {
        throw Exception('Failed to load shows');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<void> _deleteShow(String id) async {
    try {
      final response = await http.delete(Uri.parse('${ApiConfig.baseUrl}/shows/$id'));
      if (response.statusCode == 200) {
        setState(() {
          _shows.removeWhere((show) => show['_id'] == id);
        });
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Show deleted successfully")));
      } else {
        throw Exception('Failed to delete show');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  void _confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Show"),
        content: const Text("Are you sure you want to delete this show?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              _deleteShow(id);
              Navigator.pop(context);
            },
            child: const Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  List<dynamic> _getShowsByCategory(String category) {
    return _shows.where((show) => show['category'] == category).toList();
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      _buildShowList("Movies", _getShowsByCategory("movie")),
      _buildShowList("Anime", _getShowsByCategory("anime")),
      _buildShowList("Series", _getShowsByCategory("series")),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Home")),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text("Menu", style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              title: const Text("Profile"),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const ProfilePage()));
              },
            ),
            ListTile(
              title: const Text("Add Show"),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const AddShowPage()));
              },
            ),
          ],
        ),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.movie), label: "Movies"),
          BottomNavigationBarItem(icon: Icon(Icons.animation), label: "Anime"),
          BottomNavigationBarItem(icon: Icon(Icons.tv), label: "Series"),
        ],
      ),
    );
  }

  Widget _buildShowList(String title, List<dynamic> shows) {
    return ListView.builder(
      itemCount: shows.length,
      itemBuilder: (context, index) {
        final show = shows[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: ListTile(
            leading: show['image'] != null
                ? Image.network(show['image'], width: 50, height: 50, fit: BoxFit.cover)
                : const Icon(Icons.image, size: 50),
            title: Text(show['title'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            subtitle: Text(show['description'], maxLines: 2, overflow: TextOverflow.ellipsis),
            trailing: IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _confirmDelete(show['_id']),
            ),
          ),
        );
      },
    );
  }
}
