import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import 'add_show_page.dart';
import 'profile_page.dart';
import 'update_show_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  List<dynamic> movies = [];
  List<dynamic> anime = [];
  List<dynamic> series = [];
  bool isLoading = true;

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey = 
      GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => isLoading = true);
    await fetchShows();
    setState(() => isLoading = false);
  }

  Future<void> fetchShows() async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/shows'),
        headers: {'Cache-Control': 'no-cache'},
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> allShows = jsonDecode(response.body);
        
        setState(() {
          movies = allShows.where((show) => show['category'] == 'movie').toList();
          anime = allShows.where((show) => show['category'] == 'anime').toList();
          series = allShows.where((show) => show['category'] == 'serie').toList();
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${e.toString()}")),
      );
    }
  }

  Future<void> deleteShow(int id) async {
    try {
      final response = await http.delete(
        Uri.parse('${ApiConfig.baseUrl}/shows/$id'),
        headers: ApiConfig.headers,
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Show deleted successfully")),
        );
        fetchShows();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to delete show")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${e.toString()}")),
      );
    }
  }

  Future<bool> _confirmDelete(int id) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Confirm Delete"),
        content: const Text("Are you sure you want to delete this show?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  void _updateShowLocally(dynamic updatedShow) {
    setState(() {
      movies.removeWhere((show) => show['id'] == updatedShow['id']);
      anime.removeWhere((show) => show['id'] == updatedShow['id']);
      series.removeWhere((show) => show['id'] == updatedShow['id']);

      switch (updatedShow['category']) {
        case 'movie':
          movies.add(updatedShow);
          break;
        case 'anime':
          anime.add(updatedShow);
          break;
        case 'serie':
          series.add(updatedShow);
          break;
      }
    });
  }

  void _navigateToAddPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddShowPage()),
    ).then((newShow) {
      if (newShow != null) {
        _updateShowLocally(newShow);
        _refreshIndicatorKey.currentState?.show();
      }
    });
  }

  void _navigateToUpdatePage(dynamic show) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UpdateShowPage(
          showId: show['id'],
          initialTitle: show['title'],
          initialDescription: show['description'],
          initialCategory: show['category'],
          initialImageUrl: show['image'] ?? '',
        ),
      ),
    ).then((updatedShow) {
      if (updatedShow != null) {
        _updateShowLocally(updatedShow);
      }
    });
  }

  Widget _buildDeleteBackground() {
    return Container(
      color: Colors.red,
      alignment: Alignment.centerRight,
      padding: const EdgeInsets.only(right: 20),
      child: const Icon(Icons.delete, color: Colors.white),
    );
  }

  Widget _buildShowImage(dynamic show) {
    if (show['image'] != null) {
      return Image.network(
        '${ApiConfig.baseUrl}${show['image']}',
        width: 50,
        height: 50,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => 
          const Icon(Icons.broken_image, size: 50),
      );
    }
    return const Icon(Icons.movie, size: 50);
  }

  Widget _buildShowList(List<dynamic> shows) {
    return RefreshIndicator(
      key: _refreshIndicatorKey,
      onRefresh: fetchShows,
      child: ListView.builder(
        itemCount: shows.length,
        itemBuilder: (context, index) {
          final show = shows[index];
          return Dismissible(
            key: Key(show['id'].toString()),
            background: _buildDeleteBackground(),
            direction: DismissDirection.endToStart,
            confirmDismiss: (direction) => _confirmDelete(show['id']),
            onDismissed: (direction) => deleteShow(show['id']),
            child: Card(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: ListTile(
                leading: _buildShowImage(show),
                title: Text(show['title']),
                subtitle: Text(show['description']),
                trailing: IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _navigateToUpdatePage(show),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Show App"),
        backgroundColor: Colors.blueAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => _refreshIndicatorKey.currentState?.show(),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blueAccent),
              child: Text("Menu", style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text("Profile"),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ProfilePage()),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.add),
              title: const Text("Add Show"),
              onTap: _navigateToAddPage,
            ),
          ],
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : IndexedStack(
              index: _selectedIndex,
              children: [
                _buildShowList(movies),
                _buildShowList(anime),
                _buildShowList(series),
              ],
            ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.movie), label: "Movies"),
          BottomNavigationBarItem(icon: Icon(Icons.animation), label: "Anime"),
          BottomNavigationBarItem(icon: Icon(Icons.tv), label: "Series"),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blueAccent,
        onTap: (index) => setState(() => _selectedIndex = index),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddPage,
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}