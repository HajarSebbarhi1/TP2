import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import 'add_show_page.dart';
import 'profile_page.dart';

class HomePage extends StatefulWidget {  // Correction: StatefulWidget au lieu de StateFullWidget
  const HomePage({super.key});  // Correction: accolades {} au lieu de parenthèses ()

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  List<dynamic> movies = [];  // Correction: movies au lieu de movie
  List<dynamic> anime = [];
  List<dynamic> series = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();  // Correction: ajout du point-virgule
    fetchShows();  // Ajout de l'appel à la méthode fetchShows()
  }

  Future<void> fetchShows() async {
    try {
      final response = await http.get(Uri.parse('${ApiConfig.baseUrl}/shows'));
      
      if (response.statusCode == 200) {
        List<dynamic> allShows = jsonDecode(response.body);
        
        setState(() {
          movies = allShows.where((show) => show['category'] == 'movie').toList();
          anime = allShows.where((show) => show['category'] == 'anime').toList();
          series = allShows.where((show) => show['category'] == 'serie').toList();
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to load shows")),
        );
      }
    } catch (e) {